import numpy as np
from tqdm import tqdm

from connect4.connect_state import ConnectState
from groups.PlayerRandom1.policy import Random
from groups.PlayerRules1.policy import RandomBeater1
from groups.PlayerRBP1.policy import RandomBeaterPro


# ---------------------------------------------------------
# Parámetros de entrenamiento
# ---------------------------------------------------------

NUM_EPISODES = 800000
PRINT_EVERY = 1000
SAVE_EVERY = 5000
EVAL_EVERY = 10000

# Recompensas (shaping agresivo para acelerar aprendizaje)
REWARD_WIN = 20.0
REWARD_LOSE = -20.0
REWARD_DRAW = -2.0
REWARD_STEP = -0.1


# ---------------------------------------------------------
# Construcción de oponentes y planificación del currículum
# ---------------------------------------------------------

def build_opponents():
    random_agent = Random()
    random_agent.mount()

    rules_agent = RandomBeater1()
    rules_agent.mount()

    # Versión del propio agente en modo evaluación, sin entrenamiento
    strong_agent = RandomBeaterPro(training_mode=False, mcts_time_limit=0.5, rl_action_prob=0.0)
    strong_agent.mount()

    return random_agent, rules_agent, strong_agent


def select_opponent(episode_idx, random_agent, rules_agent, strong_agent):
    """
    Currículum:
      - 0–40% episodios: contra Random (exploración básica).
      - 40–80% episodios: contra RandomBeater1 (reglas).
      - 80–100% episodios: contra versión fuerte del propio agente.
    """
    frac = episode_idx / NUM_EPISODES

    if frac < 0.4:
        return random_agent
    elif frac < 0.8:
        return rules_agent
    else:
        return strong_agent


# ---------------------------------------------------------
# Evaluación periódica del agente
# ---------------------------------------------------------

def evaluate(agent, opponent, num_games=200):
    """
    Evalúa el agente sin actualizar Q-table.
    """
    wins = 0
    draws = 0
    loses = 0

    eval_agent = RandomBeaterPro(training_mode=False, mcts_time_limit=1.0, rl_action_prob=0.0)
    eval_agent.mount()
    # Copia de la Q-table aprendida
    eval_agent.q_table = dict(agent.q_table)

    for g in range(num_games):
        state = ConnectState()
        done = False

        # Alternar quién empieza para evitar sesgos
        turn = -1 if g % 2 == 0 else 1

        while not done:
            current_player = state.player

            if current_player == turn:
                action = eval_agent.act(state.board)
            else:
                action = opponent.act(state.board)

            state = state.transition(action)
            done = state.is_final()

        winner = state.get_winner()
        if winner == turn:
            wins += 1
        elif winner == -turn:
            loses += 1
        else:
            draws += 1

    total = max(1, wins + draws + loses)
    win_rate = wins / total
    draw_rate = draws / total
    lose_rate = loses / total

    print(f"\n[Evaluación] vs {type(opponent).__name__} en {num_games} partidas:")
    print(f"  Victorias: {wins} ({win_rate:.3f})")
    print(f"  Empates  : {draws} ({draw_rate:.3f})")
    print(f"  Derrotas : {loses} ({lose_rate:.3f})\n")


# ---------------------------------------------------------
# Entrenamiento principal del agente RandomBeaterPro
# ---------------------------------------------------------

def train():
    # Agente RL híbrido
    rl_agent = RandomBeaterPro(training_mode=True, mcts_time_limit=0.2, rl_action_prob=0.15)
    rl_agent.mount()   # Carga Q-table si existe

    # Oponentes
    random_agent, rules_agent, strong_agent = build_opponents()

    print("Entrenando RandomBeaterPro...")
    print(f"Episodios totales: {NUM_EPISODES}")

    for episode in tqdm(range(NUM_EPISODES), desc="Entrenando"):
        state = ConnectState()
        done = False

        # Historial de jugadas del agente para actualizar Q-table al final
        rl_move_history = []

        # Alternar quién empieza
        turn = -1 if episode % 2 == 0 else 1

        # Selección del oponente según currículum
        opponent = select_opponent(episode, random_agent, rules_agent, strong_agent)

        while not done:
            current_player = state.player

            if current_player == turn:
                board_state = state.board.copy()
                action = rl_agent.act(board_state)

                rl_move_history.append(
                    {
                        "state": board_state,
                        "action": action,
                    }
                )
                state = state.transition(action)

            else:
                action = opponent.act(state.board)
                state = state.transition(action)

            done = state.is_final()

        # Final de partida: asignación de recompensa
        winner = state.get_winner()

        if not rl_move_history:
            continue

        if winner == turn:
            final_reward = REWARD_WIN
        elif winner == -turn:
            final_reward = REWARD_LOSE
        else:
            final_reward = REWARD_DRAW

        # Actualización de Q-table: último movimiento recibe recompensa final,
        # los anteriores llevan penalización por paso para fomentar victorias rápidas.
        for i, move in enumerate(reversed(rl_move_history)):
            reward = final_reward if i == 0 else REWARD_STEP

            if i == 0:
                next_state_board = state.board
            else:
                next_state_board = rl_move_history[-i]["state"]

            rl_agent.update_q_table(
                state=move["state"],
                action=move["action"],
                reward=reward,
                next_state=next_state_board,
            )

        # Decaimiento de epsilon (aunque la exploración principal viene de MCTS/UCB1)
        rl_agent.decay_epsilon()

        # Guardado periódico
        if (episode + 1) % SAVE_EVERY == 0:
            rl_agent.save_q_table()

        # Evaluación periódica en fases clave, sin detener el entrenamiento
        if (episode + 1) % EVAL_EVERY == 0:
            # Evaluación rápida contra cada tipo de oponente
            evaluate(rl_agent, random_agent, num_games=100)
            evaluate(rl_agent, rules_agent, num_games=100)
            evaluate(rl_agent, strong_agent, num_games=100)

    # Guardado final
    rl_agent.save_q_table()
    print("\nEntrenamiento completado.")


if __name__ == "__main__":
    train()
