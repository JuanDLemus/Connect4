# Auto-generated policy table: state -> best action index
POLICY_TABLE = {}
